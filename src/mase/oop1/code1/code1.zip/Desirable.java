package mase.oop1.code1;

public interface Desirable {

}
