package mase.oop1.code1;

public interface Machine {
	public void start();
	public void stop();
	public double getPrice();
}
